<?php

namespace Valtech\Engrave\Plugin;

use Magento\Quote\Model\Quote\Item\ToOrderItem;

/**
 * EngraveQuoteToCart
 */
class EngraveQuoteToCart
{
    /**
     * @param ToOrderItem $subject
     * @param callable $proceed
     * @param $quoteItem
     * @param $data
     * @return mixed
     */
    public function aroundConvert(ToOrderItem $subject, callable $proceed, $quoteItem, $data)
    {
        $orderItem = $proceed($quoteItem, $data);
        $engraveMessage = $quoteItem->getEngrave();
        $orderItem->setEngrave($engraveMessage);
        return $orderItem;
    }
}
