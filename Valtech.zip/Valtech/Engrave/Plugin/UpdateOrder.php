<?php
/**
 * Copyright © Valtech All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Valtech\Engrave\Plugin;

use Magento\Sales\Model\Order;

/**
 * UpdateOrder
 */
class UpdateOrder
{
    /**
     * @param Order $subject
     * @param $result
     * @return mixed
     */
    public function afterPlace(
        Order $subject,
              $result
    ) {
        $result->getgetAllItems();
        foreach ($result->getAllItems() as $item) {
            if ($item->getEngrave()) {
                $result->setEngrave(true);
                return $result;
            }
        }
        return $result;
    }
}
