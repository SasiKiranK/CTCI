<?php
/**
 * Copyright © 1.0.1 All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Valtech\Engrave\Plugin;

use Magento\Framework\App\Request\Http;
use Magento\Quote\Model\Quote;

/**
 * Class AddEngraveQuoteItem
 */
class AddEngraveQuoteItem
{
    /**
     * @var Http
     */
    private $request;

    /**
     * @param Http $request
     */
    public function __construct(
        Http $request
    ) {
        $this->request = $request;
    }

    /**
     * @param Quote $subject
     * @param $result
     * @param $product
     * @param $request
     * @param $processMode
     * @return mixed
     */
    public function afterAddProduct(
        Quote $subject,
              $result,
              $product,
              $request = null,
              $processMode = 'full'
    ) {
        $engrave = $this->request->getParam('engrave');
        $result->setEngrave($engrave);
        return $result;
    }
}
